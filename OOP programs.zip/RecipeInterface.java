package recipe;

import java.util.List;

public interface RecipeInterface {
    void addRecipe(Recipe recipe);
    void removeRecipe(String recipeName);
    Recipe findRecipe(String recipeName);
    List<Recipe> listRecipes();
    List<Recipe> searchByIngredient(String ingredient);
}

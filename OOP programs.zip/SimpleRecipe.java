package recipe;

import java.util.List;

public class SimpleRecipe extends Recipe {
    public SimpleRecipe(String name, List<String> ingredients, String instructions) {
        super(name, ingredients, instructions);
    }

    @Override
    public void displayRecipe() {
    System.out.println("Name: " + getName());
    System.out.println("Ingredients: " + String.join(", ", getIngredients()));
    System.out.println("Instructions: " + getInstructions());
    System.out.println();
}
    @Override
    public String toString() {
        return name + "\nIngredients: " + String.join(", ", ingredients) + "\nInstructions: " + instructions;
    }

    
}

package recipe;

import java.util.List;

public abstract class Recipe {
    protected String name;
    protected List<String> ingredients;
    protected String instructions;

    public Recipe(String name, List<String> ingredients, String instructions) {
        this.name = name;
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    public abstract void displayRecipe();

    public String getName() {
        return name;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public String getInstructions() {
        return instructions;
    }
}



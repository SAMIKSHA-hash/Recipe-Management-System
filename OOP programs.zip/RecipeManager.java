package recipe;

import java.util.ArrayList;
import java.util.List;

public class RecipeManager implements RecipeInterface {
    private List<Recipe> recipes = new ArrayList<>();

    @Override
    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    @Override
    public void removeRecipe(String recipeName) {
        recipes.removeIf(r -> r.getName().equalsIgnoreCase(recipeName));
    }

    @Override
    public Recipe findRecipe(String recipeName) {
        return recipes.stream()
                      .filter(r -> r.getName().equalsIgnoreCase(recipeName))
                      .findFirst()
                      .orElse(null);
    }

    @Override
    public List<Recipe> listRecipes() {
        return new ArrayList<>(recipes);
    }

    @Override
    public List<Recipe> searchByIngredient(String ingredient) {
        List<Recipe> results = new ArrayList<>();
        for (Recipe recipe : recipes) {
            for (String recipeIngredient : recipe.getIngredients()) {
                if (recipeIngredient.equalsIgnoreCase(ingredient)) {
                    results.add(recipe);
                    break;  // Move to the next recipe after finding a match
                }
            }
        }
        return results; // Fixed the formatting issue here
    }
}

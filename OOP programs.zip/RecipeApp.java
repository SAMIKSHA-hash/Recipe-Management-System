package recipe;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class RecipeApp {
    public static void main(String[] args) {
        RecipeManager recipeManager = new RecipeManager();
        FileManager fileManager = new FileManager();
        Scanner scanner = new Scanner(System.in);

        // Load existing recipes from file
        try {
            List<Recipe> loadedRecipes = fileManager.loadRecipes("recipes.txt");
            loadedRecipes.forEach(recipeManager::addRecipe);
        } catch (IOException e) {
            System.out.println("Error loading recipes: " + e.getMessage());
        }

        while (true) {
            System.out.println("1. Add Recipe\n2. View Recipes\n3. Delete Recipe\n4. Search Recipe by Ingredient\n5. Save Recipes\n6. Exit");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter recipe name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter ingredients (comma-separated): ");
                    List<String> ingredients = List.of(scanner.nextLine().split(","));
                    System.out.print("Enter instructions: ");
                    String instructions = scanner.nextLine();
                    recipeManager.addRecipe(new SimpleRecipe(name, ingredients, instructions));
                    break;

                case "2":
                    recipeManager.listRecipes().forEach(Recipe::displayRecipe);
                    break;

                case "3":
                    System.out.print("Enter recipe name to delete: ");
                    recipeManager.removeRecipe(scanner.nextLine());
                    break;

                case "4":
                    System.out.print("Enter ingredient to search: ");
                    List<Recipe> foundRecipes = recipeManager.searchByIngredient(scanner.nextLine());
                    if (foundRecipes.isEmpty()) {
                        System.out.println("No recipes found with that ingredient.");
                    } else {
                        foundRecipes.forEach(Recipe::displayRecipe); 
                    }
                    break;
                

                case "5":
                    try {
                        fileManager.saveRecipes(recipeManager.listRecipes(), "recipes.txt");
                        System.out.println("Recipes saved successfully.");
                    } catch (IOException e) {
                        System.out.println("Error saving recipes: " + e.getMessage());
                    }
                    break;

                case "6":
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

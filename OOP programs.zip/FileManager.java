package recipe;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    public void saveRecipes(List<Recipe> recipes, String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Recipe recipe : recipes) {
                writer.write(recipe.getName() + ";" + String.join(",", recipe.getIngredients()) + ";" + recipe.getInstructions());
                writer.newLine();
            }
        }
    }

    public List<Recipe> loadRecipes(String filename) throws IOException {
        List<Recipe> recipes = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                String name = parts[0];
                List<String> ingredients = List.of(parts[1].split(","));
                String instructions = parts[2];
                recipes.add(new SimpleRecipe(name, ingredients, instructions));
            }
        }
        return recipes;
    }
}
